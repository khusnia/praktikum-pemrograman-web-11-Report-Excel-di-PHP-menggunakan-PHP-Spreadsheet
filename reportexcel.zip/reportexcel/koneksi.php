<?php 
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "db_siswa";
$koneksi    = mysqli_connect($host, $user, $password, $database);
?>